# Journey to the West / expansion 31–48 / R03

User explicitly authorized extending the first thirty to forty-eight. Produce the previously proposed eighteen: Queen Mother, Pagoda King Li, Taibai Jinxing, Yanluo, Lingji, Jinchi, Lingxuzi, Tiger/Deer/Goat Strength Immortals, Azure Lion, White Elephant, Nine-Headed Beast, Nine-Spirit Sage, Hundred-Eyed Lord, White Mouse Spirit, Spiritual-Touch King and Yellow Lion.

Keep ALL youthful human faces. No aged facial anatomy, beards, animal muzzle, scales, whiskers, fur or beak. Species cues use symbolic jewelry, cloth motifs and personal props. Side-profile upper-chest crop, decisive black contours, flat colored eyes, hard cel shadows and true transparent PNG follow the accepted human Wukong master and current live human reference.

Gender reversals and expressions distinguish the cast. Taibai, Lingji, Deer Strength and Nine-Spirit Sage intentionally close their eyes. The eighteen briefs contain nine male and nine female interpretations. These are original youthful human reinterpretations rather than claims about canonical game models. Background research remains in ../journey-west-human-collection-01/research.md.

Delivery includes eighteen new source PNGs, eighteen-character board, unified forty-eight-character board and combined archive referencing the original thirty without modifying them. Figma creates a new historical Assets page for all forty-eight, reusing existing thirty asset fills. No website deployment requested in this turn.
